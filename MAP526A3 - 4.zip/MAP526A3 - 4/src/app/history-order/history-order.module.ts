import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HistoryOrdersPageRoutingModule } from './history-order-routing.module';
import { HistoryOrdersPage } from './history-order.page';
import { ComponentsModule } from '../partials/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HistoryOrdersPageRoutingModule,
    ComponentsModule
  ],
  declarations: [HistoryOrdersPage]
})
export class HistoryOrdersPageModule {}
