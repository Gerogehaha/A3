import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/partials/interfaces/orders.interface';
import { HistoryService } from 'src/app/partials/services/history.service';

@Component({
  selector: 'app-history-order',
  templateUrl: './history-order.page.html',
  styleUrls: ['./history-order.page.scss'],
})
export class HistoryOrdersPage implements OnInit {

  ordersHistory: Order[] = []
  constructor(private history: HistoryService) { }

  ngOnInit() {
    this.ordersHistory = this.history.getOrdersHistory;
  }

}
