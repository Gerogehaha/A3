import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CurrentOrdersPage } from './current-order.page';

const routes: Routes = [
  {
    path: '',
    component: CurrentOrdersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CurrentOrdersPageRoutingModule {}
