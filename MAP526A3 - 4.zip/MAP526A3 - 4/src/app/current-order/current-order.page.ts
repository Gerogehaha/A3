import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/partials/interfaces/orders.interface';
import { HistoryService } from 'src/app/partials/services/history.service';
import { OrderService } from 'src/app/partials/services/order.service';
import { Confirm } from 'src/app/partials/interfaces/modals.interface';

@Component({
  selector: 'app-current-order',
  templateUrl: './current-order.page.html',
  styleUrls: ['./current-order.page.scss'],
})
export class CurrentOrdersPage implements OnInit {
  isOrder: boolean = false;
  myOrder: Order = null;
  constructor(private order: OrderService, private history: HistoryService) { }

  ngOnInit() {  
    console.log(this.order.getOrder);
    this.myOrder = this.order.getOrder;

    if(this.myOrder !== null ) {
      this.isOrder = true;
    }
  }

  ionViewDidLeave(){
    if(!this.isOrder){
      this.myOrder = null;
    }
    console.log('did Leave', this.isOrder, this.myOrder)
  }

  placeOrder(){
    this.history.addOrder(this.myOrder);    
    Confirm.fire({
      icon: 'success',
      title: 'Thank you!',
      text: 'Order was placed successfully'
    })
  }

  removeItem(index: number){
    if(this.myOrder.order.length <= 1) {
      this.isOrder = false;
      return this.order.clearOrder();
    }

    this.myOrder.quantity -= this.myOrder.order[index].qty
    this.myOrder.total -= this.myOrder.order[index].price
    this.myOrder.order.splice(index, 1);

    console.log(this.myOrder)
    this.order.updateOrder(this.myOrder);
  }
}
