import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { CurrentOrdersPageRoutingModule } from './current-order-routing.module';
import { CurrentOrdersPage } from './current-order.page';
import { ComponentsModule } from '../partials/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CurrentOrdersPageRoutingModule,
    ComponentsModule
  ],
  declarations: [CurrentOrdersPage]
})
export class CurrentOrdersPageModule {}
