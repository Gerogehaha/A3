import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { MyOrderPageRoutingModule } from './manager-routing.module';
import { MyOrderPage } from './manager.page';
import { ComponentsModule } from '../partials/components.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MyOrderPageRoutingModule,
    ComponentsModule
  ],
  declarations: [MyOrderPage]
})
export class MyOrderPageModule {}
