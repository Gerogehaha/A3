import { Component, OnInit } from '@angular/core';
import { CancelOrder, Success2 } from 'src/app/partials/interfaces/modals.interface';
import { OrderService } from '../partials/services/order.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.page.html',
  styleUrls: ['./manager.page.scss'],
})
export class MyOrderPage implements OnInit {

  constructor(private order: OrderService, private router: Router) { }

  ngOnInit() {
  }

  newOrder(){
    CancelOrder.fire({}).then((result) => {
      if(result.isConfirmed) {
        Success2.fire(
          'Cancelled!',
          'Your order has been cancelled',
          'success',          
        );
        this.order.clearOrder();
        console.log('order cleared');
        this.router.navigate(['/home']);
      }
    })

    console.log('order cancelled')    
  }
}
