import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DigitComponent } from './digit/digit.component';
import { IonicModule } from '@ionic/angular';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    DigitComponent, 
    HeaderComponent
  ],
  imports: [
    CommonModule,
    IonicModule
  ],
  exports: [
    DigitComponent,
    HeaderComponent
  ],
})
export class ComponentsModule { }
