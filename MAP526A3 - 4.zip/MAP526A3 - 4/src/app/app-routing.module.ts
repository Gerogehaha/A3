import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./main/main.module').then( m => m.HomePageModule)
  },
  {
    path: 'myOrder',
    loadChildren: () => import('./manager/manager.module').then( m => m.MyOrderPageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'currentOrder',
    loadChildren: () => import('./current-order/current-order.module').then( m => m.CurrentOrdersPageModule)
  },
  {
    path: 'updateOrder',
    loadChildren: () => import('./update-order/update-order.module').then( m => m.UpdateOrderPageModule)
  },
  {
    path: 'historyOrders',
    loadChildren: () => import('./history-order/history-order.module').then( m => m.HistoryOrdersPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
