import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-order',
  templateUrl: './update-order.page.html',
  styleUrls: ['./update-order.page.scss'],
})
export class UpdateOrderPage implements OnInit {
  constructor() { }
  ngOnInit() { }
}
